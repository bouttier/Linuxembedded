#include "ip.h" // pour getIp
#include "font.h" // pour getFont
#include "gui.h" // pour toute les structures et fonctions graphiques

void buttonEvent(TS_button* button, int event, void* args);
