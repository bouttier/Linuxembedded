#include <sys/dir.h> // pour opendir/readdir
#include <string.h> // pour sscanf
#include <stdlib.h>
#include <stdio.h>

int getFont(char* path, int* size);
